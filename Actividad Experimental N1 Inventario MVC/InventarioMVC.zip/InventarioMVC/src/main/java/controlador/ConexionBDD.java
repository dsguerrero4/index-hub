/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Samir
 */
public class ConexionBDD {
    Connection con;
    String driver ="com.mysql.cj.jdbc.Driver";
    String bdName = "inventario";
    String url ="jdbc:mysql://localhost:3306/"+ bdName+ "?zeroDateTimeBehavior=CONVERT_TO_NULL";
    String usuario ="root";
    String clave = "";
    
    public Connection conectarBaseDeDatos(){
        try {
            Class.forName(driver);
            con = DriverManager.getConnection(url, usuario, clave);
            System.out.println("Conexion exitosa");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Error en la conexion: "+ e);
        }
        return con;
    }
    public static void main(String[] args) {
        Connection con;
        ConexionBDD conexion = new ConexionBDD();
        con = conexion.conectarBaseDeDatos();
    }
}

