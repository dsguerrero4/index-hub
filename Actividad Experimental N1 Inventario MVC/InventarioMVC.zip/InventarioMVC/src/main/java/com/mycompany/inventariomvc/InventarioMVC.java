/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inventariomvc;

/**
 *
 * @author Samir
 */
class InventarioMVC {
    }
