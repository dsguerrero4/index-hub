package com.mycompany.tareanosql; // Tu paquete

import org.bson.Document;
import java.util.List;

interface Database {
    void insert(Document document);
    List<Document> findAll();
    // ... otros métodos (update, delete, etc.)
}