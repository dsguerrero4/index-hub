package com.mycompany.tareanosql; // Tu paquete

import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

public class TaskManager {
    private Database database;

    public TaskManager(Database database) {
        this.database = database;
    }

    public void createTask(Task task) {
        Document document = new Document("name", task.getName())
                .append("edad", task.getEdad())
                .append("genero", task.getGenero());
        database.insert(document);
    }

    public List<Task> getAllTasks() {
        List<Document> documents = database.findAll();
        List<Task> tasks = new ArrayList<>();
        for (Document document : documents) {
            Task task = new Task(document.getString("name"), document.getString("edad"), document.getString("genero"));
            tasks.add(task);
        }
        return tasks;
    }

    // ... otros métodos (update, delete, etc.)
}