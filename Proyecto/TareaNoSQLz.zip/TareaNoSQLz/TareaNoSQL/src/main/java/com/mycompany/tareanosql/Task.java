package com.mycompany.tareanosql; // Tu paquete

public class Task {
    private String name;
    private String edad;
    private String genero;

    public Task(String name, String edad, String genero) {
        this.name = name;
        this.edad = edad;
        this.genero = genero;
    }

    // Getters y setters para name, edad y genero
    public String getName() { return name; }
    public String getEdad() { return edad; }
    public String getGenero() { return genero; }

    public void setName(String name) { this.name = name; }
    public void setEdad(String edad) { this.edad = edad; }
    public void setGenero(String genero) { this.genero = genero; }
}