/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.tareanosql;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;

public class MongoDBConnection {
    private final MongoClient mongoClient;

    public MongoDBConnection(String uri) {
        this.mongoClient = MongoClients.create(uri);
    }

    public MongoClient getMongoClient() {
        return mongoClient;
    }
}