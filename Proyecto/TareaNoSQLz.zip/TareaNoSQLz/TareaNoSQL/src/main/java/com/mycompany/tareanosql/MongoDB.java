package com.mycompany.tareanosql; // Tu paquete

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import org.bson.Document;
import java.util.ArrayList;
import java.util.List;

public class MongoDB implements Database {
    private final MongoCollection<Document> collection;

    public MongoDB(MongoCollection<Document> collection) {
        this.collection = collection;
    }

    @Override
    public void insert(Document document) {
        collection.insertOne(document);
    }

    @Override
    public List<Document> findAll() {
        List<Document> documents = new ArrayList<>();
        try (MongoCursor<Document> cursor = collection.find().iterator()) {
            while (cursor.hasNext()) {
                documents.add(cursor.next());
            }
        }
        return documents;
    }

    // ... otros métodos (update, delete, etc.)
}