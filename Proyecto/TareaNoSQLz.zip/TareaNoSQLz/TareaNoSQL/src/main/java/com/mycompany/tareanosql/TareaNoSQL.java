/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.tareanosql;

/**
 *
 * @author Samir
 */
public class TareaNoSQL {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
