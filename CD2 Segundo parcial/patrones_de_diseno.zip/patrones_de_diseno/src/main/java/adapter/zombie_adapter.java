/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

/**
 *
 * @author Samir
 */
public class zombie_adapter implements enemigo{

    private zombie zombie;
    
    public zombie_adapter(){
        this.zombie = new zombie();
    }
    
    @Override
    public void atacar() {
        int value = (int) (Math.random()*10);
        if(value % 2 == 0)
            zombie.morder();
        else
            zombie.golpear();
    }

    @Override
    public void dano() {
        int value = (int) (Math.random()*10);
        if(value % 2 == 0)
            zombie.dano_en_la_cabeza();
        else
            zombie.dano_en_el_cuerpo();
    }
}
