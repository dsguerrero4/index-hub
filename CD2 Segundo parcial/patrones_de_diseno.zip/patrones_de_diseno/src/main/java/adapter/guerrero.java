/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

/**
 *
 * @author Samir
 */
public class guerrero implements enemigo{

    @Override
    public void atacar() {
        System.out.println("guerrero ataca!");
    }

    @Override
    public void dano() {
        System.out.println("guerrero daño!");
    }
    
}
