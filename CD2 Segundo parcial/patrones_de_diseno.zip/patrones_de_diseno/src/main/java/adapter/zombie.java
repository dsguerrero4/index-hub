/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

/**
 *
 * @author Samir
 */
public class zombie {
    
    public void morder(){
        System.out.println("zombie muerde");
    }
    
    public void golpear(){
        System.out.println("zombie golpea");
    }
    
    public void dano_en_la_cabeza(){
        System.out.println("dano en la cabeza!");
    }
    
    public void dano_en_el_cuerpo(){
        System.out.println("dano en el cuerpo!");
    }
}
