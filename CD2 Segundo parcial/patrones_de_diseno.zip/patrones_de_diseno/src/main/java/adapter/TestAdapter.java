/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package adapter;

/**
 *
 * @author Samir
 */
public class TestAdapter {
    public static void main(String[] args){
        zombie_adapter zombie = new zombie_adapter();
        zombie.atacar();
        zombie.dano();
    }
}
