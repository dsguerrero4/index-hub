/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Samir
 */
public class stickman extends boss implements MyObservable {

    private List<MyObserver> observers = new ArrayList<>();

    public stickman(String name){
        super(name);
        setActive(true);
    }

    @Override
    public void subscribe(MyObserver observer) {
        observers.add(observer);
    }

    @Override
    public void unsubscribe(MyObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void broadcast() {
        for (MyObserver observer : observers) {
            observer.update();
        }
    }
    
    @Override
    public void attack() {
        System.out.println(getName() + " stickman al ataque!");
    }

    @Override
    public void activate() {
        System.out.println(getName() + " enviando mensajes");
        broadcast();
    }
}