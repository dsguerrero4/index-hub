/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author Samir
 */
public class TestObservable {
    public static void main(String[] args){
        personaje personaje1 = new personaje("personaje 1");
        personaje personaje2 = new personaje("personaje 2");
        player player1 = new player("player 1");
        player player2 = new player("player 2");
        stickman stickman = new stickman("stickman");
        
        stickman.subscribe(personaje1);
        stickman.subscribe(personaje2);
        stickman.subscribe(player1);
        stickman.subscribe(player2);
        
        stickman.activate();
        System.out.println("================================");
        stickman.unsubscribe(player2);
        stickman.activate();
    }
}
