/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author Samir
 */
public class player extends boss implements MyObserver {

    public player(String name) {
        super(name);
        setActive(false);
    }
    
    @Override
    public void update() {
        activate();
        attack();
    }
    
    @Override
    public void attack() {
        System.out.println(getName() + " player al ataque!");
    }

    @Override
    public void activate() {
        setActive(true);
        System.out.println(getName() + " player esta activo");
    }
}
