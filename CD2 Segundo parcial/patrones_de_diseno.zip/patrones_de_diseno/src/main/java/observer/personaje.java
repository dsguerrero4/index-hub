/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package observer;

/**
 *
 * @author Samir
 */
public class personaje extends boss implements MyObserver {

    public personaje(String name) {
        super(name);
        setActive(false);
    }
    
    @Override
    public void update() {
        activate();
        attack();
    }
    
    @Override
    public void attack() {
        System.out.println(getName() + " personaje al ataque!");
    }

    @Override
    public void activate() {
        setActive(true);
        System.out.println(getName() + " personaje esta activo");
    }
}