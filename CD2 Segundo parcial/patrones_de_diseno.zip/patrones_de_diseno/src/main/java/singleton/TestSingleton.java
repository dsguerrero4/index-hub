/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package singleton;

/**
 *
 * @author Samir
 */
public class TestSingleton {
    public static void main(String[] args){
        Thread threadSamir = new Thread(new RunSamir());
        Thread threadDarwin = new Thread(new RunDarwin());
        
        threadSamir.start();
        threadDarwin.start();
    }
    
    static class RunSamir implements Runnable{

        @Override
        public void run() {
            singleton Singleton = singleton.getSingleton("Samir");
            System.out.println("Running Samir: " + Singleton);
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
    
    static class RunDarwin implements Runnable{

        @Override
        public void run() {
            singleton Singleton = singleton.getSingleton("Darwin");
            System.out.println("Running Darwin: " + Singleton);
            throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        }
    }
}
