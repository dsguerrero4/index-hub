/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package singleton;

/**
 *
 * @author Samir
 */
public class singleton {
    
    private String name;
    private static volatile singleton Singleton;
    
    private singleton(String name){
        try {
            Thread.sleep(1000);
        } catch (Exception e) {
            e.printStackTrace();
        }
        this.name = name;
    }
    
    public static synchronized singleton getSingleton(String name){
        if(Singleton == null)
            Singleton = new singleton(name);
        return Singleton;
    }

    @Override
    public String toString() {
        return "singleton{" + "name=" + name + '}';
    }
}
